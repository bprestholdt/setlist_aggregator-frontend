export default function SetlistCredit() {
  return (
    <p style={{ fontSize: '0.75rem', marginTop: '1rem' }}>
      Setlist data provided by <a href="https://www.setlist.fm" target="_blank" rel="noopener noreferrer">Setlist.fm</a>
    </p>
  );
}
